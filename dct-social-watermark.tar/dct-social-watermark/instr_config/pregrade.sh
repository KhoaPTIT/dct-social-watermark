#!/bin/bash
# Normalize collected checkwork artifacts before autoGrade reads results.config.
# This keeps grading stable whether files were copied to the xfer root or under
# a container-named subdirectory.
set +e

LAB="dct-social-watermark"
REPORTS="cover_report.txt embed_report.txt facebook_report.txt zalo_report.txt web_report.txt extract_facebook_report.txt extract_zalo_report.txt extract_web_report.txt comparison_report.txt tuning_report.txt robustness_memo_report.txt summary_report.txt"

# If checkwork copied files into a subdirectory, mirror them into the current
# grader working directory because instr_config/results.config uses plain names.
for subdir in "$LAB" "./$LAB"; do
    if [ -d "$subdir" ]; then
        for f in $REPORTS; do
            if [ -f "$subdir/$f" ] && [ ! -f "$f" ]; then
                cp "$subdir/$f" "$f"
            fi
        done
    fi
done

# Missing files should grade as incomplete, not crash the grader.
for f in $REPORTS; do
    if [ ! -f "$f" ]; then
        touch "$f"
    fi
done

exit 0
