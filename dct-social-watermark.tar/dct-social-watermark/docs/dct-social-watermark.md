# DCT Social Watermark

This Labtainer lab asks students to attack a DCT-domain image watermark with realistic social-media upload transformations: resize, JPEG recompression, metadata stripping, PNG-to-JPEG conversion, and color-space conversion.

The practice flow is:

```bash
python3 generate_cover.py
python3 embed_watermark.py --alpha 35
python3 social_pipeline.py --platform facebook
python3 social_pipeline.py --platform zalo
python3 social_pipeline.py --platform web
python3 extract_watermark.py --image attacks/facebook_simulated.jpg
python3 extract_watermark.py --image attacks/zalo_simulated.jpg
python3 extract_watermark.py --image attacks/web_simulated.jpg
python3 compare_pipelines.py
```

Students then tune `robust_config.py` and complete `ROBUSTNESS_MEMO.md` with measured BER, confidence, and a stronger watermark configuration.
