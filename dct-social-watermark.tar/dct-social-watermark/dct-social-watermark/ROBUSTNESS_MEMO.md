# Robustness Memo

TODO: Replace this line with your measured analysis.

## Required content

- Facebook BER and confidence:
- Zalo BER and confidence:
- Web thumbnail BER and confidence:
- Strongest attack pipeline:
- Chosen alpha:
- Chosen repeat:
- Why this alpha/repeat setting is more robust:
- Visual-quality tradeoff:
