import argparse

from social_watermark_helper import PLATFORMS, ensure_cover, platform_report_name, simulate_platform, work_path, write_json, write_report

parser = argparse.ArgumentParser(description="Simulate social-media upload transformations.")
parser.add_argument("--platform", choices=sorted(PLATFORMS), required=True)
parser.add_argument("--image", default="stego.png", help="Watermarked image to upload.")
args = parser.parse_args()

ensure_cover()
source = work_path(args.image)
if not source.exists():
    raise SystemExit("stego.png is missing; run python3 embed_watermark.py --alpha 35 first")

spec = PLATFORMS[args.platform]
out = work_path("attacks") / spec["out"]
metrics = simulate_platform(source, args.platform, out)
write_json(work_path("attacks") / f"{args.platform}_metrics.json", metrics)

if args.platform == "facebook":
    done = "Facebook social pipeline completed"
elif args.platform == "zalo":
    done = "Zalo social pipeline completed"
else:
    done = "Web thumbnail pipeline completed"

write_report(
    work_path(platform_report_name(args.platform)),
    [
        done,
        f"Output: attacks/{spec['out']}",
        f"Resize max side: {spec['max_side']} px",
        f"JPEG quality: {spec['quality']}",
        f"Output size: {metrics['output_size'][0]}x{metrics['output_size'][1]}",
        f"Metadata stripped: {metrics['metadata_stripped']}",
        f"Color-space roundtrip: {metrics['color_roundtrip']}",
        f"BER after pipeline: {metrics['ber'] * 100:.2f}%",
        f"Average confidence: {metrics['avg_confidence']:.2f}",
        f"PSNR vs stego: {metrics.get('psnr', 0):.2f} dB",
        f"SSIM vs stego: {metrics.get('ssim', 0):.4f}",
    ],
)
print(f"created attacks/{spec['out']}")
