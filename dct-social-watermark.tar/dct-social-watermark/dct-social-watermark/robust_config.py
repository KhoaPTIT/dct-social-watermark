ALPHA = 35
REPEAT = 12
TARGET_PLATFORM = "zalo"
RATIONALE = "TODO: explain the BER/confidence tradeoff and why this setting is stronger"
