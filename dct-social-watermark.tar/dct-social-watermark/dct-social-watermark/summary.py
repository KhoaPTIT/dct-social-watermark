from social_watermark_helper import PLATFORMS, read_json, work_path, write_report

required = [
    "cover.png",
    "stego.png",
    "embed_report.txt",
    "facebook_report.txt",
    "zalo_report.txt",
    "web_report.txt",
    "extract_facebook_report.txt",
    "extract_zalo_report.txt",
    "extract_web_report.txt",
    "comparison_report.txt",
    "pipeline_contact_sheet.jpg",
    "tuning_report.txt",
    "robustness_memo_report.txt",
]
missing = [name for name in required if not work_path(name).exists()]
metrics = []
for platform in PLATFORMS:
    metrics.append(read_json(work_path(f"extract_{platform}_metrics.json"), {"ber": 0, "avg_confidence": 0}))
max_ber = max((float(m.get("ber", 0)) for m in metrics), default=0)
ok = not missing and max_ber >= 0.02
write_report(
    work_path("summary_report.txt"),
    [
        "DCT social watermark lab summary completed" if ok else "DCT social watermark lab summary incomplete",
        f"Maximum observed BER: {max_ber * 100:.2f}%",
        "Missing artifacts: " + (", ".join(missing) if missing else "none"),
    ],
)
if not ok:
    raise SystemExit(1)
print("summary complete")
