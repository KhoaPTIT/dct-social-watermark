from social_watermark_helper import CANONICAL_SIZE, generate_cover_image, work_path, write_report

cover = work_path("cover.png")
generate_cover_image(cover)
write_report(
    work_path("cover_report.txt"),
    [
        "Cover image generated",
        f"Output: {cover.name}",
        f"Size: {CANONICAL_SIZE[0]}x{CANONICAL_SIZE[1]}",
        "Format: PNG with synthetic visual content",
    ],
)
print("created cover.png")
