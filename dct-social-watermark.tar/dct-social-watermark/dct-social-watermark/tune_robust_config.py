import importlib

from PIL import Image

from social_watermark_helper import (
    PLATFORMS,
    embed_bits,
    ensure_cover,
    luma_array,
    message_bits,
    normalize_image,
    save_luma_into_rgb,
    simulate_platform,
    work_path,
    write_json,
    write_report,
)

cfg = importlib.import_module("robust_config")

alpha = float(getattr(cfg, "ALPHA", 0))
repeat = int(getattr(cfg, "REPEAT", 0))
target = str(getattr(cfg, "TARGET_PLATFORM", "web"))
rationale = str(getattr(cfg, "RATIONALE", ""))

errors = []
if "TODO" in rationale or len(rationale.strip()) < 30:
    errors.append("RATIONALE must explain the alpha/repeat choice")
if target not in PLATFORMS:
    errors.append("TARGET_PLATFORM must be facebook, zalo, or web")
if alpha < 40:
    errors.append("ALPHA should be raised to at least 40 for the robust trial")
if repeat < 18:
    errors.append("REPEAT should be raised to at least 18 for the robust trial")
if errors:
    write_report(work_path("tuning_report.txt"), ["Robust watermark tuning incomplete", *errors])
    raise SystemExit(1)

ensure_cover()
cover = normalize_image(Image.open(work_path("cover.png")))
robust_y = embed_bits(luma_array(cover), message_bits(), alpha=alpha, repeat=repeat)
save_luma_into_rgb(cover, robust_y, work_path("robust_stego.png"))
metrics = simulate_platform(
    work_path("robust_stego.png"),
    target,
    work_path("attacks") / f"robust_{target}_simulated.jpg",
    repeat=repeat,
)
write_json(work_path("robust_tuning_metrics.json"), metrics)

ok = metrics["ber"] <= 0.25 and metrics.get("psnr", 0) >= 24.0
write_report(
    work_path("tuning_report.txt"),
    [
        "Robust watermark tuning completed" if ok else "Robust watermark tuning incomplete",
        f"Target platform: {target}",
        f"Alpha: {alpha}",
        f"Repeat: {repeat}",
        f"BER: {metrics['ber'] * 100:.2f}%",
        f"Average confidence: {metrics['avg_confidence']:.2f}",
        f"PSNR vs robust stego: {metrics.get('psnr', 0):.2f} dB",
        f"Rationale: {rationale}",
    ],
)
if not ok:
    raise SystemExit(1)
print("robust tuning passed")
