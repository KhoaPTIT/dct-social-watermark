from social_watermark_helper import PLATFORMS, contact_sheet, read_json, work_path, write_json, write_report

rows = []
missing = []
for platform, spec in PLATFORMS.items():
    metric_path = work_path("extract_" + platform + "_metrics.json")
    if not metric_path.exists():
        metric_path = work_path("attacks") / f"{platform}_metrics.json"
    if not metric_path.exists():
        missing.append(platform)
        continue
    metrics = read_json(metric_path, {})
    rows.append(
        {
            "platform": platform,
            "label": spec["label"],
            "ber": float(metrics.get("ber", 0.0)),
            "confidence": float(metrics.get("avg_confidence", 0.0)),
            "psnr": float(metrics.get("psnr", 0.0)),
            "ssim": float(metrics.get("ssim", 0.0)),
        }
    )

if missing:
    raise SystemExit("missing extraction metrics for: " + ", ".join(missing))

rows.sort(key=lambda r: (r["ber"], -r["confidence"]), reverse=True)
strongest = rows[0]
write_json(work_path("comparison_metrics.json"), {"strongest": strongest["platform"], "rows": rows})
contact_sheet(
    [
        ("stego.png", work_path("stego.png")),
        ("facebook_simulated.jpg", work_path("attacks/facebook_simulated.jpg")),
        ("zalo_simulated.jpg", work_path("attacks/zalo_simulated.jpg")),
        ("web_simulated.jpg", work_path("attacks/web_simulated.jpg")),
    ],
    work_path("pipeline_contact_sheet.jpg"),
)
lines = [
    "Social pipeline comparison completed",
    f"Strongest pipeline: {strongest['label']} ({strongest['ber'] * 100:.2f}% BER)",
    "",
    "Ranked by BER:",
]
for row in rows:
    lines.append(
        f"- {row['label']}: BER={row['ber'] * 100:.2f}% confidence={row['confidence']:.2f} "
        f"PSNR={row['psnr']:.2f} SSIM={row['ssim']:.4f}"
    )
write_report(work_path("comparison_report.txt"), lines)
print(f"strongest pipeline: {strongest['platform']}")
