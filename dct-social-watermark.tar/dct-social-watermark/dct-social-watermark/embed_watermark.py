import argparse

from PIL import Image, PngImagePlugin

from social_watermark_helper import (
    DEFAULT_ALPHA,
    DEFAULT_REPEAT,
    MESSAGE,
    embed_bits,
    ensure_cover,
    luma_array,
    message_bits,
    normalize_image,
    read_json,
    save_luma_into_rgb,
    work_path,
    write_json,
    write_report,
)

parser = argparse.ArgumentParser(description="Embed a text watermark in DCT mid-frequency coefficients.")
parser.add_argument("--alpha", type=float, default=DEFAULT_ALPHA, help="DCT coefficient margin.")
parser.add_argument("--repeat", type=int, default=DEFAULT_REPEAT, help="Number of block votes per bit.")
parser.add_argument("--image", default="cover.png", help="Input cover PNG.")
parser.add_argument("--out", default="stego.png", help="Output watermarked PNG.")
args = parser.parse_args()

if args.repeat < 1:
    raise SystemExit("--repeat must be >= 1")
if args.alpha <= 0:
    raise SystemExit("--alpha must be positive")

ensure_cover()
source = work_path(args.image)
img = normalize_image(Image.open(source))
y = luma_array(img)
stego_y = embed_bits(y, message_bits(), alpha=args.alpha, repeat=args.repeat)
meta = PngImagePlugin.PngInfo()
meta.add_text("lab", "dct-social-watermark")
meta.add_text("watermark_message", MESSAGE)
meta.add_text("alpha", str(args.alpha))
meta.add_text("repeat", str(args.repeat))
save_luma_into_rgb(img, stego_y, work_path(args.out), pnginfo=meta)

params = read_json(work_path("watermark_params.json"), {})
params.update({"alpha": args.alpha, "repeat": args.repeat, "message": MESSAGE, "output": args.out})
write_json(work_path("watermark_params.json"), params)
write_report(
    work_path("embed_report.txt"),
    [
        "DCT watermark embedded",
        f"Input: {args.image}",
        f"Output: {args.out}",
        f"Message: {MESSAGE}",
        f"Alpha: {args.alpha}",
        f"Repeat: {args.repeat}",
    ],
)
print(f"embedded watermark into {args.out}")
