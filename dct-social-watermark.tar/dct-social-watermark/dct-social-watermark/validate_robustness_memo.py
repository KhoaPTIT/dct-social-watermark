from social_watermark_helper import work_path, write_report

path = work_path("ROBUSTNESS_MEMO.md")
text = path.read_text(encoding="utf-8") if path.exists() else ""
lower = text.lower()
required = ["facebook", "zalo", "web", "ber", "confidence", "alpha", "repeat", "robust"]
missing = [word for word in required if word not in lower]
ok = "TODO" not in text and len(text.split()) >= 90 and not missing
write_report(
    work_path("robustness_memo_report.txt"),
    [
        "Robustness memo accepted" if ok else "Robustness memo incomplete",
        "Missing keywords: " + (", ".join(missing) if missing else "none"),
        f"Word count: {len(text.split())}",
    ],
)
if not ok:
    raise SystemExit(1)
print("memo accepted")
