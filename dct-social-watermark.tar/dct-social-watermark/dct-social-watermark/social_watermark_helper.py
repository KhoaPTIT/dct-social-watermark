from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

try:
    from scipy.fftpack import dct, idct
except Exception:
    dct = None
    idct = None


LAB_NAME = "dct-social-watermark"
MESSAGE = "DCT SOCIAL WATERMARK B22DCAT164"
CANONICAL_SIZE = (2304, 1536)
BLOCK_SIZE = 8
COEFF_A = (3, 4)
COEFF_B = (4, 3)
SEED = 1642026
DEFAULT_ALPHA = 35
DEFAULT_REPEAT = 12

RESAMPLE_NEAREST = getattr(getattr(Image, "Resampling", Image), "NEAREST")
RESAMPLE_BILINEAR = getattr(getattr(Image, "Resampling", Image), "BILINEAR")
RESAMPLE_BICUBIC = getattr(getattr(Image, "Resampling", Image), "BICUBIC")
RESAMPLE_LANCZOS = getattr(getattr(Image, "Resampling", Image), "LANCZOS")

PLATFORMS = {
    "facebook": {
        "max_side": 2048,
        "quality": 75,
        "strip_metadata": True,
        "png_to_jpeg": True,
        "color_roundtrip": False,
        "out": "facebook_simulated.jpg",
        "label": "Facebook",
    },
    "zalo": {
        "max_side": 1600,
        "quality": 68,
        "strip_metadata": True,
        "png_to_jpeg": True,
        "color_roundtrip": True,
        "out": "zalo_simulated.jpg",
        "label": "Zalo",
    },
    "web": {
        "max_side": 512,
        "quality": 60,
        "strip_metadata": True,
        "png_to_jpeg": True,
        "color_roundtrip": False,
        "out": "web_simulated.jpg",
        "label": "Web thumbnail",
    },
}

_DCT_MATRIX = None


def script_dir() -> Path:
    return Path(__file__).resolve().parent


def work_path(name: str) -> Path:
    return script_dir() / name


def ensure_dirs() -> None:
    work_path("attacks").mkdir(exist_ok=True)


def read_json(path: str | Path, default: dict | None = None) -> dict:
    p = Path(path)
    if not p.exists():
        return default or {}
    return json.loads(p.read_text(encoding="utf-8"))


def write_json(path: str | Path, data: dict) -> None:
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def write_report(path: str | Path, lines: list[str]) -> None:
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def message_bits(message: str = MESSAGE) -> list[int]:
    bits: list[int] = []
    for byte in message.encode("ascii"):
        for shift in range(7, -1, -1):
            bits.append((byte >> shift) & 1)
    return bits


def bits_to_message(bits: list[int]) -> str:
    data = bytearray()
    for i in range(0, len(bits), 8):
        chunk = bits[i : i + 8]
        if len(chunk) < 8:
            break
        value = 0
        for bit in chunk:
            value = (value << 1) | int(bit)
        data.append(value)
    return data.decode("ascii", errors="replace")


def bit_error_rate(expected: list[int], recovered: list[int]) -> float:
    errors = sum(a != b for a, b in zip(expected, recovered))
    errors += abs(len(expected) - len(recovered))
    return 0.0 if not expected else errors / len(expected)


def dct_matrix() -> np.ndarray:
    global _DCT_MATRIX
    if _DCT_MATRIX is not None:
        return _DCT_MATRIX
    n = BLOCK_SIZE
    mat = np.zeros((n, n), dtype=np.float64)
    for k in range(n):
        scale = math.sqrt(1.0 / n) if k == 0 else math.sqrt(2.0 / n)
        for i in range(n):
            mat[k, i] = scale * math.cos(math.pi * (2 * i + 1) * k / (2 * n))
    _DCT_MATRIX = mat
    return mat


def dct2(block: np.ndarray) -> np.ndarray:
    if dct is not None:
        return dct(dct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat @ block @ mat.T


def idct2(block: np.ndarray) -> np.ndarray:
    if idct is not None:
        return idct(idct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat.T @ block @ mat


def normalize_image(img: Image.Image, size: tuple[int, int] = CANONICAL_SIZE) -> Image.Image:
    img = img.convert("RGB")
    if img.size != size:
        img = img.resize(size, RESAMPLE_BICUBIC)
    return img


def luma_array(img: Image.Image) -> np.ndarray:
    return np.asarray(img.convert("YCbCr").split()[0], dtype=np.float64)


def save_luma_into_rgb(source: Image.Image, y: np.ndarray, path: str | Path, pnginfo=None) -> None:
    source = normalize_image(source)
    ycbcr = source.convert("YCbCr")
    channels = list(ycbcr.split())
    channels[0] = Image.fromarray(np.clip(np.rint(y), 0, 255).astype(np.uint8), mode="L")
    Image.merge("YCbCr", channels).convert("RGB").save(path, pnginfo=pnginfo)


def psnr(a: np.ndarray, b: np.ndarray) -> float:
    mse = np.mean((a.astype(np.float64) - b.astype(np.float64)) ** 2)
    if mse <= 1e-12:
        return 99.0
    return 20.0 * math.log10(255.0 / math.sqrt(mse))


def ssim(a: np.ndarray, b: np.ndarray) -> float:
    a = a.astype(np.float64)
    b = b.astype(np.float64)
    c1 = (0.01 * 255) ** 2
    c2 = (0.03 * 255) ** 2
    mu_a, mu_b = a.mean(), b.mean()
    var_a, var_b = a.var(), b.var()
    cov = ((a - mu_a) * (b - mu_b)).mean()
    return float(((2 * mu_a * mu_b + c1) * (2 * cov + c2)) / ((mu_a**2 + mu_b**2 + c1) * (var_a + var_b + c2)))


def block_order(bit_count: int, repeat: int, size: tuple[int, int] = CANONICAL_SIZE, seed: int = SEED) -> np.ndarray:
    w, h = size
    blocks_x = w // BLOCK_SIZE
    blocks_y = h // BLOCK_SIZE
    total = blocks_x * blocks_y
    need = bit_count * repeat
    if need > total:
        raise ValueError("watermark is too large for this image/repeat setting")
    rng = np.random.default_rng(seed)
    return rng.permutation(total)[:need]


def generate_cover_image(path: Path) -> None:
    w, h = CANONICAL_SIZE
    y, x = np.mgrid[0:h, 0:w]
    gradient = 48 + 92 * (x / (w - 1)) + 64 * (y / (h - 1))
    waves = 16 * np.sin(x / 24.0) + 13 * np.cos(y / 19.0) + 9 * np.sin((x + y) / 41.0)
    rng = np.random.default_rng(SEED)
    noise = rng.normal(0, 7, (h, w))
    base = np.clip(gradient + waves + noise, 0, 255)
    rgb = np.dstack(
        [
            np.clip(base + 26 * np.sin(y / 80.0), 0, 255),
            np.clip(base + 22 * np.cos(x / 95.0), 0, 255),
            np.clip(230 - base / 3 + 24 * np.sin((x - y) / 73.0), 0, 255),
        ]
    ).astype(np.uint8)
    img = Image.fromarray(rgb, mode="RGB")
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()
    draw.rectangle((96, 96, w - 96, h - 96), outline=(245, 245, 245), width=6)
    draw.rectangle((180, 210, 770, 720), outline=(210, 55, 55), width=12)
    draw.ellipse((1180, 190, 1740, 760), outline=(40, 105, 215), width=14)
    draw.line((180, 1130, w - 180, 860), fill=(248, 224, 54), width=12)
    draw.line((220, 1290, w - 220, 1290), fill=(34, 34, 34), width=6)
    poly = [(1110, 1110), (1390, 925), (1810, 1185), (1540, 1430)]
    draw.line(poly + [poly[0]], fill=(30, 150, 95), width=12)
    draw.text((230, 805), "DCT SOCIAL WATERMARK", fill=(255, 255, 255), font=font)
    draw.text((1185, 805), "UPLOAD PIPELINE", fill=(18, 18, 18), font=font)
    draw.text((230, 1410), "PNG -> RESIZE -> JPEG -> METADATA STRIP", fill=(252, 252, 252), font=font)
    img.save(path, pnginfo=None)


def ensure_cover() -> Path:
    path = work_path("cover.png")
    if not path.exists():
        generate_cover_image(path)
    return path


def embed_bits(y: np.ndarray, bits: list[int], alpha: float, repeat: int, seed: int = SEED) -> np.ndarray:
    out = y.copy()
    order = block_order(len(bits), repeat=repeat, seed=seed)
    blocks_x = CANONICAL_SIZE[0] // BLOCK_SIZE
    for idx, block_index in enumerate(order):
        bit = bits[idx // repeat]
        by = (int(block_index) // blocks_x) * BLOCK_SIZE
        bx = (int(block_index) % blocks_x) * BLOCK_SIZE
        block = out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0
        coeff = dct2(block)
        a, b = coeff[COEFF_A], coeff[COEFF_B]
        diff = a - b
        target = float(alpha) if bit else -float(alpha)
        if (bit and diff < target) or ((not bit) and diff > target):
            adjust = (target - diff) / 2.0
            coeff[COEFF_A] = a + adjust
            coeff[COEFF_B] = b - adjust
        out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] = idct2(coeff) + 128.0
    return np.clip(out, 0, 255)


def extract_bits(y: np.ndarray, repeat: int, seed: int = SEED) -> tuple[list[int], list[float]]:
    bits = message_bits()
    order = block_order(len(bits), repeat=repeat, seed=seed)
    blocks_x = CANONICAL_SIZE[0] // BLOCK_SIZE
    recovered: list[int] = []
    confidence: list[float] = []
    for bit_index in range(len(bits)):
        votes: list[int] = []
        margins: list[float] = []
        for rep in range(repeat):
            block_index = int(order[bit_index * repeat + rep])
            by = (block_index // blocks_x) * BLOCK_SIZE
            bx = (block_index % blocks_x) * BLOCK_SIZE
            block = y[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0
            coeff = dct2(block)
            diff = float(coeff[COEFF_A] - coeff[COEFF_B])
            votes.append(1 if diff > 0 else 0)
            margins.append(abs(diff))
        recovered.append(1 if sum(votes) >= len(votes) / 2.0 else 0)
        confidence.append(float(np.mean(margins)))
    return recovered, confidence


def read_embed_params() -> dict:
    return read_json(work_path("watermark_params.json"), {"alpha": DEFAULT_ALPHA, "repeat": DEFAULT_REPEAT})


def extract_metrics(image: Path, repeat: int | None = None, reference: Path | None = None) -> dict:
    params = read_embed_params()
    repeat = int(repeat or params.get("repeat", DEFAULT_REPEAT))
    img = normalize_image(Image.open(image))
    y = luma_array(img)
    bits, confidence = extract_bits(y, repeat=repeat)
    expected = message_bits()
    metrics = {
        "image": str(image),
        "message": bits_to_message(bits),
        "ber": bit_error_rate(expected, bits),
        "accuracy": 1.0 - bit_error_rate(expected, bits),
        "avg_confidence": float(np.mean(confidence)),
        "min_confidence": float(np.min(confidence)),
        "repeat": repeat,
        "bits": bits,
    }
    if reference and reference.exists():
        ref = luma_array(normalize_image(Image.open(reference)))
        metrics["psnr"] = psnr(ref, y)
        metrics["ssim"] = ssim(ref, y)
    return metrics


def simulate_platform(source: Path, platform: str, out: Path, repeat: int | None = None) -> dict:
    spec = PLATFORMS[platform]
    img = Image.open(source).convert("RGB")
    original_size = img.size
    max_side = int(spec["max_side"])
    longest = max(img.size)
    if longest > max_side:
        scale = max_side / float(longest)
        new_size = (int(round(img.size[0] * scale)), int(round(img.size[1] * scale)))
        img = img.resize(new_size, RESAMPLE_LANCZOS)
    if spec["color_roundtrip"]:
        img = img.convert("YCbCr").convert("RGB")
    out.parent.mkdir(exist_ok=True)
    img.save(out, "JPEG", quality=int(spec["quality"]), optimize=False, subsampling=2)
    metrics = extract_metrics(out, repeat=repeat, reference=source)
    metrics.update(
        {
            "platform": platform,
            "label": spec["label"],
            "original_size": list(original_size),
            "output_size": list(img.size),
            "jpeg_quality": int(spec["quality"]),
            "metadata_stripped": bool(spec["strip_metadata"]),
            "png_to_jpeg": bool(spec["png_to_jpeg"]),
            "color_roundtrip": bool(spec["color_roundtrip"]),
        }
    )
    return metrics


def bit_error_map(bits: list[int], out_path: Path) -> None:
    expected = message_bits()
    cols = 32
    rows = int(math.ceil(len(expected) / cols))
    small = np.zeros((rows, cols, 3), dtype=np.uint8)
    small[:, :] = (42, 52, 65)
    for i, (a, b) in enumerate(zip(expected, bits)):
        y, x = divmod(i, cols)
        small[y, x] = (218, 64, 75) if a != b else (62, 184, 112)
    img = Image.fromarray(small, mode="RGB").resize((512, max(128, rows * 16)), RESAMPLE_NEAREST)
    img.save(out_path)


def contact_sheet(items: list[tuple[str, Path]], out: Path) -> None:
    cell_w, cell_h = 360, 250
    cols = 2
    rows = int(math.ceil(len(items) / cols))
    sheet = Image.new("RGB", (cols * cell_w, rows * cell_h), (245, 246, 248))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    for idx, (label, path) in enumerate(items):
        row, col = divmod(idx, cols)
        x0, y0 = col * cell_w, row * cell_h
        if path.exists():
            img = Image.open(path).convert("RGB")
            img.thumbnail((340, 200), RESAMPLE_BICUBIC)
            sheet.paste(img, (x0 + 10, y0 + 10))
        draw.text((x0 + 12, y0 + 220), label[:48], fill=(20, 24, 33), font=font)
    sheet.save(out)


def platform_report_name(platform: str) -> str:
    return f"{platform}_report.txt"


def extraction_prefix(image: Path) -> str:
    stem = image.stem
    if stem.endswith("_simulated"):
        stem = stem[: -len("_simulated")]
    return stem


def parse_args() -> argparse.ArgumentParser:
    return argparse.ArgumentParser()
