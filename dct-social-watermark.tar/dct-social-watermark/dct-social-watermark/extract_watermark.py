import argparse
from pathlib import Path

from social_watermark_helper import bit_error_map, extract_metrics, extraction_prefix, work_path, write_json, write_report

parser = argparse.ArgumentParser(description="Extract the DCT-domain watermark and report BER.")
parser.add_argument("--image", required=True, help="Image to test, for example attacks/facebook_simulated.jpg")
parser.add_argument("--repeat", type=int, default=None, help="Override repeat count used for voting.")
args = parser.parse_args()

image = work_path(args.image) if not Path(args.image).is_absolute() else Path(args.image)
if not image.exists():
    raise SystemExit(f"missing image: {image}")

metrics = extract_metrics(image, repeat=args.repeat, reference=work_path("stego.png"))
prefix = extraction_prefix(image)
write_json(work_path(f"extract_{prefix}_metrics.json"), metrics)
bit_error_map(metrics["bits"], work_path(f"{prefix}_bit_errors.png"))
write_report(
    work_path(f"extract_{prefix}_report.txt"),
    [
        "Watermark extraction completed",
        f"Image: {args.image}",
        f"Recovered message: {metrics['message']}",
        f"BER: {metrics['ber'] * 100:.2f}%",
        f"Accuracy: {metrics['accuracy'] * 100:.2f}%",
        f"Average confidence: {metrics['avg_confidence']:.2f}",
        f"Repeat: {metrics['repeat']}",
    ],
)
print(f"BER {metrics['ber'] * 100:.2f}% from {args.image}")
