# DCT Social Watermark

Bài lab mô phỏng tấn công thực tế vào giấu tin/watermark trong ảnh dựa trên biến đổi miền tần số DCT. Watermark được nhúng vào hệ số trung tần của các block 8x8 trên kênh độ sáng. Sau đó ảnh được đưa qua các pipeline giống quá trình upload lên mạng xã hội: resize, nén JPEG, xóa metadata, đổi PNG sang JPG, và đổi không gian màu.

Watermark bí mật:

```text
DCT SOCIAL WATERMARK B22DCAT164
```

## Mục tiêu

- Nhúng watermark vào ảnh PNG bằng DCT.
- Mô phỏng upload Facebook.
- Mô phỏng upload Zalo.
- Mô phỏng upload web thumbnail.
- Trích xuất watermark sau từng pipeline và đo BER.
- So sánh pipeline nào phá watermark mạnh nhất.
- Điều chỉnh `alpha` và `repeat`.
- Đề xuất cấu hình watermark bền hơn trong memo.

## Luồng thực hành nhanh

Chạy lần lượt:

```bash
python3 generate_cover.py
python3 embed_watermark.py --alpha 35
python3 social_pipeline.py --platform facebook
python3 social_pipeline.py --platform zalo
python3 social_pipeline.py --platform web
python3 extract_watermark.py --image attacks/facebook_simulated.jpg
python3 extract_watermark.py --image attacks/zalo_simulated.jpg
python3 extract_watermark.py --image attacks/web_simulated.jpg
python3 compare_pipelines.py
```

Mở các report để xem kết quả:

```bash
cat facebook_report.txt
cat zalo_report.txt
cat web_report.txt
cat extract_facebook_report.txt
cat extract_zalo_report.txt
cat extract_web_report.txt
cat comparison_report.txt
```

Có thể dùng `eog` để xem ảnh:

```bash
eog cover.png
eog stego.png
eog attacks/facebook_simulated.jpg
eog attacks/zalo_simulated.jpg
eog attacks/web_simulated.jpg
eog pipeline_contact_sheet.jpg
```

## Pipeline mô phỏng

Facebook:

- Resize cạnh dài về tối đa 2048 px.
- Nén JPEG quality 75.
- Xóa metadata.
- Chuyển PNG sang JPG.

Zalo:

- Resize cạnh dài về tối đa 1600 px.
- Nén JPEG mạnh hơn, quality 68.
- Xóa metadata.
- Chuyển qua YCbCr rồi quay lại RGB trước khi lưu JPEG.

Web upload thumbnail:

- Resize cạnh dài về 512 px.
- Nén JPEG quality 60.
- Xóa metadata.
- Chuyển PNG sang JPG.

## Điều chỉnh độ bền

Sửa `robust_config.py`. Cấu hình ban đầu cố tình chưa đạt:

```python
ALPHA = 35
REPEAT = 12
TARGET_PLATFORM = "zalo"
RATIONALE = "TODO: explain the BER/confidence tradeoff and why this setting is stronger"
```

Gợi ý:

- Tăng `ALPHA` để tạo khoảng cách hệ số DCT lớn hơn.
- Tăng `REPEAT` để mỗi bit có nhiều block vote hơn.
- Quan sát BER, confidence và PSNR để tránh làm ảnh xuống chất lượng quá rõ.
- Web thumbnail 512 px thường phá watermark rất mạnh; nếu chỉ chỉnh `alpha` và `repeat`, hãy ghi rõ giới hạn này trong memo.

Sau khi sửa, chạy:

```bash
python3 tune_robust_config.py
```

## Memo

Sửa `ROBUSTNESS_MEMO.md`, xóa dòng `TODO`, và ghi phân tích có số đo thực nghiệm:

- BER và confidence của Facebook, Zalo, Web.
- Pipeline phá mạnh nhất.
- Alpha/repeat đã chọn.
- Vì sao cấu hình mới bền hơn.
- Đánh đổi giữa độ bền watermark và chất lượng ảnh.

Kiểm tra memo:

```bash
python3 validate_robustness_memo.py
```

## Hoàn tất

Chạy:

```bash
python3 summary.py
checkwork
```

Expected checkwork labname:

```text
dct-social-watermark
```
